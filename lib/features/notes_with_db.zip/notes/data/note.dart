class Note {
  final String title;
  final String content;
  final String category;
  final DateTime createdAt;

  Note({
    required this.title,
    required  this.category,
    required this.content,
    required this.createdAt,
  });

  Note copyWith({ String? title, String? content, DateTime? createdAt,String? category}) {
    return Note(
      title: title ?? this.title,
      category: category ?? this.category,
      content: content ?? this.content,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}


extension NoteMapper on Note {
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'content': content,
      'color': color,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  static Note fromJson(Map<String, Object?> json) {
    return Note(
      id: json['id'] as int?,
      title: json['title'] as String,
      content: json['content'] as String?,
      color: json['color'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
    );
  }
}
